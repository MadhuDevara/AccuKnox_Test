
# System Health Monitoring Script

This project contains a Python script that monitors the health of a Linux system, including:
- CPU usage
- Memory usage
- Disk space usage
- Running processes

Alerts are logged if any of the metrics exceed predefined thresholds.

## Requirements:
- Python 3.x
- psutil library (`pip install psutil`)

## Running the Script:
- Navigate to the project directory and run `python system_health_monitor.py`

## Logs:
- Alerts are stored in the `logs/health.log` file.
