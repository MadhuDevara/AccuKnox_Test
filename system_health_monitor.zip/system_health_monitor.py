
import psutil
import time
import logging

# Setting up logging to log alerts to a file
logging.basicConfig(filename='logs/health.log', 
                    level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# Define threshold values
CPU_THRESHOLD = 80  # 80%
MEMORY_THRESHOLD = 80  # 80%
DISK_THRESHOLD = 90  # 90% usage
CHECK_INTERVAL = 10  # Check system health every 10 seconds

def check_cpu_usage():
    """Check CPU usage and log if above threshold."""
    cpu_usage = psutil.cpu_percent(interval=1)
    if cpu_usage > CPU_THRESHOLD:
        logging.warning(f'High CPU usage detected: {cpu_usage}%')
    return cpu_usage

def check_memory_usage():
    """Check memory usage and log if above threshold."""
    memory = psutil.virtual_memory()
    memory_usage = memory.percent
    if memory_usage > MEMORY_THRESHOLD:
        logging.warning(f'High Memory usage detected: {memory_usage}%')
    return memory_usage

def check_disk_usage():
    """Check disk space usage and log if above threshold."""
    disk_usage = psutil.disk_usage('/')
    if disk_usage.percent > DISK_THRESHOLD:
        logging.warning(f'Low disk space: {disk_usage.percent}% used.')
    return disk_usage.percent

def check_running_processes():
    """Check running processes and log if any suspicious ones are found."""
    process_count = len(psutil.pids())
    logging.info(f'Running processes: {process_count}')
    return process_count

def monitor_system_health():
    """Main function to monitor system health."""
    while True:
        print("Checking system health...")
        cpu_usage = check_cpu_usage()
        memory_usage = check_memory_usage()
        disk_usage = check_disk_usage()
        process_count = check_running_processes()
        
        print(f"CPU Usage: {cpu_usage}%")
        print(f"Memory Usage: {memory_usage}%")
        print(f"Disk Usage: {disk_usage}%")
        print(f"Running Processes: {process_count}")
        
        # Wait for the defined interval before checking again
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    monitor_system_health()
